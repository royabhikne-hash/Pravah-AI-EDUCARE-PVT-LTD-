export interface TeamMember {
  id: string;
  name: string;
  role: string;
  coFounder: boolean;
  monogram: string;
  department: string;
  bio: string;
  responsibilities: string[];
  image?: string;
}

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  status: 'Live & Advancing' | 'In Active Engineering' | 'Future Vision';
  stage: 'built' | 'building' | 'envisioned';
  tagline: string;
  shortDesc: string;
  fullDesc: string;
  features: string[];
  capabilities: { title: string; desc: string }[];
  accentColor: string;
}

export interface ApproachStep {
  step: string;
  title: string;
  summary: string;
  description: string;
  details: string[];
}

export const COMPANY_DETAILS = {
  legalName: 'Pravah AI Educare Private Limited',
  shortName: 'Pravah AI',
  cin: 'U85499KA2026PTC222183',
  incorporationDate: 'July 2026',
  registeredAddress: 'SY. No. 91, Ward No. 14, Near Government Hospital, Banashankari Nagara, Rattihalli, Haveri District, Karnataka – 581116',
  officialEmail: 'connect@pravahai.com',
  secondaryEmail: 'geesumalladad@gmail.com',
  eyebrow: 'INDEPENDENTLY BUILT. FUTURE-FOCUSED.',
  heroHeadline: 'The first chapter of a larger product journey.',
  heroSubcopy: 'Pravah AI builds thoughtful technology and intelligent learning experiences designed to turn ambitious ideas into meaningful products.',
  storyHeadline: 'Good technology begins with better questions.',
  storyLead: 'Pravah AI Educare Private Limited is an independent technology company building AI-powered educational systems and innovative software products designed for real-world classrooms and learners.',
};

export const PRINCIPLES = [
  {
    number: '01',
    title: 'Think deeply.',
    summary: 'Build around real problems rather than trends.',
    description: 'We do not chase speculative technology hypes. Every product begins with grounded inquiry: what barriers prevent students from grasping core concepts, and how can intelligent tools eliminate friction without replacing human mentors?',
  },
  {
    number: '02',
    title: 'Build intentionally.',
    summary: 'Combine thoughtful design, engineering, and practical utility.',
    description: 'Great software balances rigorous engineering with emotional calm. We build systems that perform reliably in low-bandwidth environments, with clean interfaces that respect student attention and cognitive bandwidth.',
  },
  {
    number: '03',
    title: 'Create meaningful impact.',
    summary: 'Develop technology intended to deliver useful, measurable value.',
    description: 'Technology is judged by its outcomes, not its rhetoric. Our goal is to provide verified conceptual clarity, evidence-labelled learning mastery, and actionable guidance for students and educators.',
  },
];

export const PRODUCTS: ProductItem[] = [
  {
    id: 'gyanam-ai',
    name: 'Gyanam AI',
    category: 'AI-Powered EdTech Platform',
    status: 'Live & Advancing',
    stage: 'built',
    tagline: 'Clear concepts. Focused practice. Better next steps.',
    shortDesc: 'An AI-powered learning platform designed to make education more personalized, interactive, and accessible for school students.',
    fullDesc: 'Gyanam AI transforms static textbooks into dynamic, adaptive learning dialogues. Designed specifically around school curriculum standards (Classes 6–12), it guides students through complex STEM concepts, offers structured problem-solving, and generates diagnostic mastery insights without promoting rote memorization.',
    features: [
      'Interactive AI Study Helper & Doubt Solver',
      'Curriculum-aligned Exam Prep & MCQ Practice',
      'Evidence-labelled Student Mastery Ledger',
      'Adaptive Weekly Smart Diagnostic Tests',
      'Institutional & Parent Progress Overviews',
    ],
    capabilities: [
      {
        title: 'Source-Grounded Clarifications',
        desc: 'Explanations grounded strictly in verified board curricula (NCERT, State Boards), avoiding hallucinated answers.',
      },
      {
        title: 'Step-by-Step Problem Scaffolding',
        desc: 'Instead of handing out answers, the AI prompts students through intermediate reasoning steps.',
      },
      {
        title: 'Multi-lingual Understanding',
        desc: 'Native support for English, Hindi, and regional language code-switching for inclusive comprehension.',
      },
    ],
    accentColor: '#2BB673',
  },
];

export const APPROACH_STEPS: ApproachStep[] = [
  {
    step: '01',
    title: 'Discover',
    summary: 'Understand the problem and the people experiencing it.',
    description: 'We begin in the classroom, not in an abstract vacuum. We observe real students studying for competitive board examinations, identify where textbooks lose clarity, and understand the everyday constraints faced by teachers in regional schools.',
    details: [
      'Classroom & school lab observational audits',
      'Diagnostic interviews with students across Class 6–12',
      'Mapping syllabus misalignment and cognitive friction points',
    ],
  },
  {
    step: '02',
    title: 'Design',
    summary: 'Develop the product experience and technical direction.',
    description: 'We architect experiences that prioritize cognitive calm over sensationalism. Interfaces are crafted with minimalist editorial clarity, intuitive feedback loops, and strict pedagogical scaffolding that promotes active inquiry.',
    details: [
      'Distraction-free typographic design systems',
      'Pedagogical flowcharts preventing direct answer-dumping',
      'Edge-first local and cloud hybrid system architecture',
    ],
  },
  {
    step: '03',
    title: 'Build',
    summary: 'Engineer the product and test the implementation.',
    description: 'We build with modern, resilient engineering stacks. From fine-tuning domain models to implementing robust offline sync engines and reactive UI frameworks, our code is tested for resilience and extreme low-latency performance.',
    details: [
      'Type-safe React, TypeScript, and high-performance WebGL',
      'Locally deployable inference pipelines via Ollama/ONNX',
      'Automated testing suites verifying pedagogical correctness',
    ],
  },
  {
    step: '04',
    title: 'Improve',
    summary: 'Learn from feedback and refine the result.',
    description: 'Software is a living craft. We measure student engagement not through addiction metrics or endless screen time, but through genuine comprehension, evidence-backed test performance, and constructive teacher feedback.',
    details: [
      'Evidence-labelled student progress ledger audits',
      'Algorithmic recalibration of diagnostic question difficulty',
      'Continuous user feedback loops with educators',
    ],
  },
];

export const TEAM_MEMBERS: TeamMember[] = [
  {
    id: 'abhishek-roy',
    name: 'Abhishek Roy',
    role: 'Chief Executive Officer',
    coFounder: true,
    monogram: 'AB',
    image: '/abhishek-ceo.jpg',
    department: 'Executive Leadership & Strategy',
    bio: 'Leads the overarching product vision and long-term strategic direction of Pravah AI, aligning institutional partnerships with innovative educational technologies.',
    responsibilities: [
      'Company vision & strategic roadmaps',
      'Institutional alliances & school partnerships',
      'Investor relations & corporate governance',
    ],
  },
  {
    id: 'druva-sm',
    name: 'Druva S M',
    role: 'Chief Technology Officer',
    coFounder: true,
    monogram: 'DH',
    image: '/druva-cto.jpg',
    department: 'Engineering & AI Architecture',
    bio: 'Oversees core software engineering, domain-specific AI model fine-tuning, edge computing pipelines, and scalable cloud infrastructure for Pravah AI platforms.',
    responsibilities: [
      'AI model architecture & local edge pipelines',
      'Full-stack system scalability & security',
      'High-performance frontend & 3D digital experiences',
    ],
  },
  {
    id: 'sambhram-g',
    name: 'Sambhram G',
    role: 'Chief Operating Officer',
    coFounder: true,
    monogram: 'SA',
    image: '/sambhram-coo.jpg',
    department: 'Operations & Execution',
    bio: 'Drives day-to-day organizational execution, platform operations, curriculum quality assurance, and deployment logistics across school environments.',
    responsibilities: [
      'Operational workflows & sprint execution',
      'Curriculum verification & pedagogical QA',
      'Field deployment logistics & user onboarding',
    ],
  },
  {
    id: 'priyanka',
    name: 'Priyanka',
    role: 'Chief Marketing Officer',
    coFounder: true,
    monogram: 'PR',
    department: 'Brand & Growth Strategy',
    bio: 'Directs brand narrative, visual communication, community outreach, and stakeholder engagement across students, parents, and academic institutions.',
    responsibilities: [
      'Brand narrative & editorial tone',
      'Community outreach & school student engagement',
      'Digital presence & product communications',
    ],
  },
];
