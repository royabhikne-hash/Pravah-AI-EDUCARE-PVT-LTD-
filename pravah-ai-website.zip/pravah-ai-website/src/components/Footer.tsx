import React from 'react';
import { ArrowUp, ArrowUpRight } from 'lucide-react';
import { COMPANY_DETAILS } from '../data/companyData';

interface FooterProps {
  onOpenPrivacy: () => void;
  onOpenTerms: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenPrivacy, onOpenTerms }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative bg-[#08140E] text-[#FAF8F4] pt-24 pb-16 px-6 md:px-12 lg:px-20 border-t border-white/10 overflow-hidden">
      {/* Background Architectural Grid Accent */}
      <div className="absolute inset-0 bg-architectural-grid-dark opacity-20 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-16 pb-16 border-b border-white/10">
          {/* Left Column: Brand Identity */}
          <div className="md:col-span-5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <img
                  src="/pravah-logo-white.png"
                  alt="Pravah AI Educare Private Limited"
                  className="h-10 md:h-11 w-auto object-contain"
                />
              </div>

              <p className="text-sm text-gray-300 max-w-sm leading-relaxed">
                Building useful, thoughtfully engineered software products with AI at their core.
              </p>

              <div className="pt-2 text-xs font-mono text-gray-400 space-y-1">
                <p>{COMPANY_DETAILS.legalName}</p>
                <p>Incorporated under Companies Act, 2013 • Karnataka, India</p>
              </div>
            </div>

            <div className="pt-8">
              <button
                onClick={scrollToTop}
                className="group inline-flex items-center gap-2 text-xs font-mono text-gray-400 hover:text-white transition-colors"
              >
                <span className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-[#2BB673] group-hover:text-black transition-all">
                  <ArrowUp className="w-3.5 h-3.5" />
                </span>
                <span>BACK TO TOP</span>
              </button>
            </div>
          </div>

          {/* Right Columns: Navigation Links */}
          <div className="md:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-8">
            {/* Column 1: Explore */}
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#7E9787] block mb-4">
                Explore
              </span>
              <ul className="space-y-3 text-sm text-gray-300">
                <li>
                  <a href="#about" className="hover:text-white transition-colors">
                    About Pravah
                  </a>
                </li>
                <li>
                  <a href="#products" className="hover:text-white transition-colors">
                    Products & Portfolio
                  </a>
                </li>
                <li>
                  <a href="#products" className="hover:text-white transition-colors flex items-center gap-1.5 text-[#34D399]">
                    <span>Gyanam AI</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </a>
                </li>
                <li>
                  <a href="#approach" className="hover:text-white transition-colors">
                    Our Methodology
                  </a>
                </li>
                <li>
                  <a href="#team" className="hover:text-white transition-colors">
                    Founding Team
                  </a>
                </li>
              </ul>
            </div>

            {/* Column 2: Governance & Policies */}
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#7E9787] block mb-4">
                Governance
              </span>
              <ul className="space-y-3 text-sm text-gray-300">
                <li>
                  <button
                    onClick={onOpenPrivacy}
                    className="hover:text-white transition-colors text-left"
                  >
                    Privacy Commitment
                  </button>
                </li>
                <li>
                  <button
                    onClick={onOpenTerms}
                    className="hover:text-white transition-colors text-left"
                  >
                    Terms & Ethics
                  </button>
                </li>
                <li>
                  <span className="text-xs text-gray-500 font-mono block">
                    Zero-Surveillance Architecture
                  </span>
                </li>
                <li>
                  <span className="text-xs text-gray-500 font-mono block">
                    Source Ground-Truth Safeguards
                  </span>
                </li>
              </ul>
            </div>

            {/* Column 3: Contact */}
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#7E9787] block mb-4">
                Connect
              </span>
              <ul className="space-y-3 text-sm text-gray-300">
                <li>
                  <a
                    href="#contact"
                    className="hover:text-white transition-colors flex items-center gap-1.5 text-[#2BB673]"
                  >
                    <span>Contact Pravah</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </a>
                </li>
                <li className="text-xs text-gray-400 font-mono">
                  {COMPANY_DETAILS.officialEmail}
                </li>
                <li className="text-xs text-gray-400 font-mono pt-2">
                  Banashankari Nagara, Rattihalli, Haveri, Karnataka – 581116
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Attribution Strip */}
        <div className="pt-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs font-mono text-gray-400">
          <div>
            © 2026 Pravaha AI Educare Private Limited. All rights reserved.
          </div>
          <div className="text-gray-400">
            Gyanam AI is a proprietary product by Pravaha.
          </div>
        </div>
      </div>
    </footer>
  );
};
