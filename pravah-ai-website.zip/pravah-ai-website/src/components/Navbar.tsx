import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';

interface NavbarProps {
  onOpenContact: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenContact }) => {
  const [scrolled, setScrolled] = useState<boolean>(false);
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setScrolled(scrollPosition > 40);

      // Detect active section
      const sections = ['hero', 'about', 'products', 'approach', 'team', 'contact'];
      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop - 120;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'About', href: '#about', id: 'about' },
    { label: 'Products', href: '#products', id: 'products' },
    { label: 'Approach', href: '#approach', id: 'approach' },
    { label: 'Team', href: '#team', id: 'team' },
    { label: 'Contact', href: '#contact', id: 'contact' },
  ];

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'py-3.5 bg-[#FAF8F4]/85 backdrop-blur-xl border-b border-[#181C1A]/10 shadow-[0_4px_24px_rgba(0,0,0,0.03)]'
            : 'py-6 bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
          {/* Logo & Mark */}
          <a
            href="#hero"
            onClick={(e) => scrollToSection(e, '#hero')}
            className="flex items-center group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0E2419] rounded-md"
            aria-label="Pravah AI Home"
          >
            <img
              src="/pravah-logo-full.png"
              alt="Pravah AI Educare Private Limited"
              className="h-10 md:h-11 w-auto object-contain transition-transform duration-300 group-hover:scale-[1.02]"
            />
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1.5 lg:gap-2.5 bg-[#FAF8F4]/70 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-[#181C1A]/8 shadow-sm">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <a
                  key={item.id}
                  href={item.href}
                  onClick={(e) => scrollToSection(e, item.href)}
                  className={`relative px-4 py-1.5 text-[13.5px] font-medium tracking-tight rounded-full transition-all duration-200 ${
                    isActive
                      ? 'text-[#0E2419] bg-[#E5ECE7]/80 font-semibold'
                      : 'text-[#343C37] hover:text-[#0E2419] hover:bg-[#FAF8F4]'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-brand-green" />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Far Right Action CTA */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={onOpenContact}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#0E2419] hover:bg-[#163525] text-[#FAF8F4] text-[13.5px] font-medium tracking-tight shadow-sm transition-all duration-200 hover:shadow-md hover:scale-[1.02] active:scale-[0.98] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0E2419]"
            >
              <span>Start a conversation</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#2BB673]" />
            </button>
          </div>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-[#181C1A] hover:bg-black/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0E2419]"
            aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 md:hidden bg-[#FAF8F4]/98 backdrop-blur-2xl pt-24 px-8 pb-10 flex flex-col justify-between">
          <div className="flex flex-col gap-6">
            <span className="text-xs font-mono tracking-widest text-[#7E9787] uppercase border-b border-[#181C1A]/10 pb-2">
              Menu Navigation
            </span>
            <nav className="flex flex-col gap-4">
              {navItems.map((item) => (
                <a
                  key={item.id}
                  href={item.href}
                  onClick={(e) => scrollToSection(e, item.href)}
                  className="text-2xl font-medium tracking-tight text-[#181C1A] hover:text-[#2BB673] flex items-center justify-between py-2 border-b border-[#181C1A]/5"
                >
                  <span>{item.label}</span>
                  <span className="text-xs font-mono text-[#7E9787]">
                    {item.id === 'contact' ? '06' : `0${navItems.indexOf(item) + 1}`}
                  </span>
                </a>
              ))}
            </nav>
          </div>

          <div className="flex flex-col gap-4 pt-6 border-t border-[#181C1A]/10">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenContact();
              }}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-full bg-[#0E2419] text-[#FAF8F4] text-sm font-semibold tracking-wide"
            >
              <span>Start a conversation</span>
              <ArrowUpRight className="w-4 h-4 text-[#2BB673]" />
            </button>
            <p className="text-center text-xs text-[#7E9787] font-mono">
              Pravah AI Educare Private Limited
            </p>
          </div>
        </div>
      )}
    </>
  );
};
