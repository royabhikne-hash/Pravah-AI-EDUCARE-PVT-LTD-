import React, { useState } from 'react';
import { APPROACH_STEPS } from '../data/companyData';
import { CheckCircle2, Sparkles } from 'lucide-react';

export const ApproachSection: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(0);

  return (
    <section id="approach" className="relative py-28 md:py-36 px-6 md:px-12 lg:px-20 bg-[#F4F0E6]/40 border-t border-[#181C1A]/10">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-mono tracking-widest text-[#5F7667] uppercase font-semibold">
              04 / Engineering Methodology
            </span>
          </div>
          <h2 className="editorial-title text-3xl sm:text-5xl md:text-6xl font-bold text-[#15202B] tracking-tight">
            How we turn questions into{' '}
            <span className="editorial-italic font-normal text-[#1B6B63]">
              systems.
            </span>
          </h2>
          <p className="text-base text-[#4E5952] mt-4">
            A disciplined four-stage cycle that balances deep pedagogical observation with rigorous full-stack engineering.
          </p>
        </div>

        {/* Step Progression Selector Tabs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
          {APPROACH_STEPS.map((step, idx) => {
            const isActive = activeStep === idx;
            return (
              <button
                key={step.step}
                onClick={() => setActiveStep(idx)}
                className={`p-5 rounded-2xl text-left transition-all duration-300 border flex flex-col justify-between ${
                  isActive
                    ? 'bg-[#0E2419] text-[#FAF8F4] border-[#0E2419] shadow-lg -translate-y-1'
                    : 'bg-[#FAF8F4] text-[#181C1A] border-[#181C1A]/10 hover:border-[#0E2419]/30'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-3">
                  <span
                    className={`font-mono font-bold text-xs ${
                      isActive ? 'text-[#2BB673]' : 'text-[#7E9787]'
                    }`}
                  >
                    STEP {step.step}
                  </span>
                  {isActive && <Sparkles className="w-4 h-4 text-[#2BB673]" />}
                </div>
                <div>
                  <h4 className="text-lg font-bold tracking-tight mb-1">{step.title}</h4>
                  <p
                    className={`text-xs line-clamp-1 ${
                      isActive ? 'text-gray-300' : 'text-[#5F7667]'
                    }`}
                  >
                    {step.summary}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Stage Editorial Deep-Dive Card */}
        {(() => {
          const current = APPROACH_STEPS[activeStep];
          return (
            <div className="rounded-3xl bg-[#FAF8F4] border border-[#181C1A]/12 p-8 md:p-12 shadow-sm">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                <div className="lg:col-span-4">
                  <span className="text-5xl md:text-6xl font-mono font-black text-[#E5ECE7] tracking-tighter block mb-2">
                    {current.step}
                  </span>
                  <h3 className="editorial-title text-2xl md:text-3xl font-bold text-[#15202B] mb-2">
                    {current.title}
                  </h3>
                  <p className="text-sm font-semibold text-[#1B6B63] mb-4 font-mono">
                    {current.summary}
                  </p>
                  <p className="text-sm text-[#4E5952] leading-relaxed">
                    {current.description}
                  </p>
                </div>

                <div className="lg:col-span-8 bg-[#F3EFE6]/60 rounded-2xl p-6 md:p-8 border border-[#181C1A]/6">
                  <span className="text-xs font-mono uppercase tracking-widest text-[#7E9787] block mb-4">
                    Key Practices & Quality Gates
                  </span>
                  <div className="space-y-4">
                    {current.details.map((detail, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-3 p-3.5 rounded-xl bg-[#FAF8F4] border border-[#181C1A]/5 text-sm text-[#181C1A]"
                      >
                        <CheckCircle2 className="w-4 h-4 text-[#2BB673] shrink-0 mt-0.5" />
                        <span>{detail}</span>
                      </div>
                    ))}
                  </div>

                  <div className="mt-8 pt-4 border-t border-[#181C1A]/10 flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-[#5F7667]">
                    <span>QUALITY AUDIT: CONTINUOUS REVIEW</span>
                    <span className="flex items-center gap-1 text-[#0E2419]">
                      Stage {activeStep + 1} of 4
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}
      </div>
    </section>
  );
};
