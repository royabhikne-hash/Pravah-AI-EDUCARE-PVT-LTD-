import React from 'react';
import { ArrowDown, ArrowUpRight, Sparkles } from 'lucide-react';
import { Hero3DCanvas } from './Hero3DCanvas';
import { COMPANY_DETAILS } from '../data/companyData';

interface HeroProps {
  onExploreWork: () => void;
  onMeetPravah: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreWork, onMeetPravah }) => {
  return (
    <section
      id="hero"
      className="relative min-h-screen w-full flex flex-col justify-between pt-32 pb-16 px-6 md:px-12 lg:px-20 bg-architectural-grid overflow-hidden"
    >
      {/* 3D Flow Ribbon Canvas in Background */}
      <Hero3DCanvas />

      {/* Subtle top architectural decorative border */}
      <div className="absolute top-24 left-6 md:left-12 right-6 md:right-12 h-px bg-[#181C1A]/10 pointer-events-none" />

      {/* Main Editorial Hero Content */}
      <div className="relative z-10 max-w-7xl mx-auto w-full my-auto py-12 pointer-events-none">
        {/* Eyebrow badge */}
        <div className="flex items-center gap-3 mb-6 pointer-events-auto">
          <div className="w-8 h-px bg-[#2BB673]" />
          <span className="text-[11px] md:text-xs font-mono uppercase tracking-[0.22em] text-[#5F7667] font-semibold">
            {COMPANY_DETAILS.eyebrow}
          </span>
          <span className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E5ECE7] border border-[#CCD8D0] text-[10px] font-mono text-[#0E2419]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#2BB673] animate-pulse" />
            Active Platform: Gyanam AI
          </span>
        </div>

        {/* Confident Large Headline */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-end">
          <div className="lg:col-span-8">
            <h1 className="editorial-title text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-extrabold text-[#15202B] tracking-tight leading-[1.03] drop-shadow-[0_1px_1px_rgba(255,255,255,0.8)]">
              The first chapter of a{' '}
              <span className="editorial-italic font-normal text-[#1B6B63] block sm:inline">
                larger product
              </span>{' '}
              journey.
            </h1>
          </div>

          {/* Right Supporting Copy & CTAs */}
          <div className="lg:col-span-4 flex flex-col justify-end gap-6 pointer-events-auto">
            <div className="p-4 sm:p-5 rounded-2xl bg-[#FAF8F4]/80 backdrop-blur-md border border-[#181C1A]/8 shadow-xs">
              <p className="text-base sm:text-lg text-[#343C37] leading-relaxed font-normal">
                {COMPANY_DETAILS.heroSubcopy}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onExploreWork}
                className="group inline-flex items-center gap-2.5 px-6 py-3.5 rounded-full bg-[#0E2419] hover:bg-[#163525] text-[#FAF8F4] text-sm font-semibold tracking-tight shadow-sm hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Explore Our Work</span>
                <ArrowDown className="w-4 h-4 text-[#2BB673] transition-transform duration-200 group-hover:translate-y-0.5" />
              </button>

              <button
                onClick={onMeetPravah}
                className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-[#FAF8F4]/90 hover:bg-[#FAF8F4] text-[#181C1A] text-sm font-semibold tracking-tight border border-[#181C1A]/15 backdrop-blur-md transition-all duration-200 hover:border-[#0E2419]/40"
              >
                <span>Meet Pravah</span>
                <ArrowUpRight className="w-4 h-4 text-[#7E9787] transition-transform duration-200 group-hover:text-[#0E2419] group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Footnote / Architectural Status Ledger */}
      <div className="relative z-10 max-w-7xl mx-auto w-full pt-8 border-t border-[#181C1A]/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs font-mono text-[#5F7667]">
        <div className="flex items-center gap-3">
          <Sparkles className="w-3.5 h-3.5 text-[#2BB673]" />
          <span>INDEPENDENT AI & EDUCARE SYSTEMS ARCHITECTURE</span>
        </div>

        <div className="flex items-center gap-6">
          <span>ORIGIN: KARNATAKA, INDIA</span>
          <span className="hidden md:inline">FOUNDED: 2026</span>
          <span className="flex items-center gap-1.5 text-[#0E2419]">
            <span className="w-2 h-2 rounded-full bg-[#2BB673]" />
            ESTABLISHED
          </span>
        </div>
      </div>
    </section>
  );
};
