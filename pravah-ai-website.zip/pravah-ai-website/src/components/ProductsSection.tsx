import React, { useState } from 'react';
import { PRODUCTS } from '../data/companyData';
import type { ProductItem } from '../data/companyData';
import { ArrowUpRight, CheckCircle2, Sparkles, BookOpen, BarChart3, HelpCircle, ShieldCheck, Layers, BookCheck, Globe2 } from 'lucide-react';

interface ProductsSectionProps {
  onSelectProduct: (product: ProductItem) => void;
}

export const ProductsSection: React.FC<ProductsSectionProps> = ({ onSelectProduct }) => {
  const [activeTabGyanam, setActiveTabGyanam] = useState<'tutor' | 'mcq' | 'progress' | 'ledger'>('tutor');

  const gyanamProject = PRODUCTS.find((p) => p.id === 'gyanam-ai')!;

  return (
    <section id="products" className="relative py-28 md:py-36 px-6 md:px-12 lg:px-20 bg-[#F4F0E6]/50 border-t border-[#181C1A]/10">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-mono tracking-widest text-[#5F7667] uppercase font-semibold">
                02 / Flagship Product
              </span>
            </div>
            <h2 className="editorial-title text-3xl sm:text-5xl md:text-6xl font-bold text-[#15202B] tracking-tight">
              Intelligence designed for{' '}
              <span className="editorial-italic font-normal text-[#1B6B63]">
                the classroom.
              </span>
            </h2>
            <p className="text-base text-[#4E5952] max-w-xl mt-3">
              An AI-powered learning companion engineered to make education personalized, interactive, and grounded in verified academic curricula.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#FAF8F4] border border-[#181C1A]/10 text-xs font-mono text-[#0E2419]">
              <span className="w-2 h-2 rounded-full bg-[#2BB673] animate-pulse" />
              DEPLOYMENT: ACTIVE & EXPANDING
            </span>
          </div>
        </div>

        {/* FEATURED FLAGSHIP: GYANAM AI */}
        <div className="rounded-3xl bg-[#FAF8F4] border border-[#181C1A]/12 shadow-md overflow-hidden">
          {/* Top Bar / Category Strip */}
          <div className="px-8 py-5 border-b border-[#181C1A]/8 flex flex-wrap items-center justify-between gap-4 bg-[#FAF8F4]">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-full bg-[#2BB673]/15 text-[#0E2419] font-mono text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#2BB673] animate-pulse" />
                FLAGSHIP PLATFORM
              </span>
              <span className="text-xs font-mono text-[#7E9787]">
                STATUS: LIVE & ADVANCING
              </span>
            </div>
            <div className="flex items-center gap-4 text-xs font-mono text-[#5F7667]">
              <span>CURRICULUM: CLASSES 6–12</span>
              <span className="hidden sm:inline">MULTILINGUAL (EN / HI / HINGLISH)</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 p-8 lg:p-12 items-center">
            {/* Left Column: Product Narrative */}
            <div className="lg:col-span-5 flex flex-col gap-6">
              <div>
                <h3 className="editorial-title text-3xl sm:text-4xl font-extrabold text-[#15202B] tracking-tight">
                  {gyanamProject.name}
                </h3>
                <p className="text-sm font-semibold text-[#1B6B63] mt-1 font-mono">
                  {gyanamProject.tagline}
                </p>
              </div>

              <p className="text-base text-[#343C37] leading-relaxed">
                {gyanamProject.shortDesc}
              </p>

              {/* Core Capabilities Checklist */}
              <div className="space-y-3 pt-2">
                {gyanamProject.features.map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-3 text-sm text-[#181C1A]">
                    <CheckCircle2 className="w-4 h-4 text-[#2BB673] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 flex flex-wrap items-center gap-3">
                <button
                  onClick={() => onSelectProduct(gyanamProject)}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#0E2419] hover:bg-[#163525] text-[#FAF8F4] text-xs font-semibold tracking-wide uppercase shadow-sm transition-all duration-200 cursor-pointer"
                >
                  <span>Inspect Platform Architecture</span>
                  <ArrowUpRight className="w-4 h-4 text-[#2BB673]" />
                </button>
                <span className="text-xs font-mono text-[#7E9787]">
                  Strict Zero-Hallucination Guardrails
                </span>
              </div>
            </div>

            {/* Right Column: Interactive Browser Frame Simulation */}
            <div className="lg:col-span-7">
              <div className="rounded-2xl border border-[#181C1A]/15 bg-[#15202B] text-white shadow-2xl overflow-hidden">
                {/* Browser Window Header */}
                <div className="px-4 py-3 bg-[#0D161F] border-b border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-[#FF5F56]" />
                    <div className="w-3 h-3 rounded-full bg-[#FFBD2E]" />
                    <div className="w-3 h-3 rounded-full bg-[#27C93F]" />
                    <span className="ml-2 px-3 py-0.5 rounded-md bg-white/5 text-[11px] font-mono text-gray-300 border border-white/5">
                      app.gyanamai.com
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] font-mono text-emerald-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    STUDENT ACTIVE SESSION
                  </div>
                </div>

                {/* Simulation Interactive Subtabs */}
                <div className="px-4 py-2 bg-[#121B24] border-b border-white/5 flex gap-2 overflow-x-auto">
                  {[
                    { id: 'tutor', label: 'AI Tutor & Doubt Solver', icon: HelpCircle },
                    { id: 'mcq', label: 'Exam Prep & MCQs', icon: BookOpen },
                    { id: 'progress', label: 'Mastery Radar', icon: BarChart3 },
                    { id: 'ledger', label: 'Evidence Ledger', icon: ShieldCheck },
                  ].map((tab) => {
                    const Icon = tab.icon;
                    const active = activeTabGyanam === tab.id;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTabGyanam(tab.id as any)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                          active
                            ? 'bg-[#2BB673]/20 text-[#34D399] border border-[#2BB673]/30'
                            : 'text-gray-400 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        <span>{tab.label}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Interactive Screen Preview */}
                <div className="p-6 bg-[#0E1720] min-h-[340px] flex flex-col justify-between">
                  {activeTabGyanam === 'tutor' && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-xs font-mono text-gray-400 pb-2 border-b border-white/10">
                        <span>SUBJECT: Class 10 Physics — Refraction of Light</span>
                        <span className="text-[#34D399]">PEDAGOGICAL MODE: SOCRATIC</span>
                      </div>

                      {/* Student Doubt */}
                      <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 max-w-[85%] self-end ml-auto">
                        <p className="text-xs text-emerald-200 font-mono mb-1">Student Doubt:</p>
                        <p className="text-sm text-gray-100">
                          "Why does a pencil dipped in a glass of water look bent?"
                        </p>
                      </div>

                      {/* AI Tutor Response */}
                      <div className="p-4 rounded-xl bg-[#162723] border border-[#2BB673]/30 max-w-[95%]">
                        <div className="flex items-center gap-2 mb-2">
                          <Sparkles className="w-3.5 h-3.5 text-[#34D399]" />
                          <span className="text-xs font-mono text-[#34D399] font-semibold">
                            Gyanam AI Tutor • Step 1 of 2
                          </span>
                        </div>
                        <p className="text-sm text-gray-200 leading-relaxed">
                          Think about what happens to speed when you move from running on dry pavement into swimming through water. Does your movement slow down?
                        </p>
                        <p className="text-xs text-gray-300 mt-2 font-mono bg-black/20 p-2 rounded">
                          💡 Light behaves identically: as light travels from optically rarer air into denser water, its speed drops, causing the light rays to bend towards the normal!
                        </p>
                      </div>

                      <div className="text-[11px] font-mono text-gray-500 pt-1">
                        ✓ Response verified against NCERT Physics Class 10 Chapter 9.
                      </div>
                    </div>
                  )}

                  {activeTabGyanam === 'mcq' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-xs font-mono text-gray-400 pb-2 border-b border-white/10">
                        <span>EXAM PREP: Bihar & CBSE Board Format</span>
                        <span className="text-yellow-400">CLASS 10 MATHEMATICS</span>
                      </div>
                      <div className="p-3 bg-white/5 rounded-xl border border-white/10">
                        <p className="text-sm font-medium text-gray-100">
                          Q. If one zero of the quadratic polynomial x² + 3x + k is 2, then the value of k is:
                        </p>
                        <div className="grid grid-cols-2 gap-2 mt-3 text-xs font-mono">
                          <div className="p-2.5 rounded-lg bg-white/5 border border-white/10 hover:border-emerald-400 cursor-pointer">
                            A) 10
                          </div>
                          <div className="p-2.5 rounded-lg bg-[#2BB673]/20 border border-[#2BB673] text-emerald-300 flex items-center justify-between">
                            <span>B) -10</span>
                            <span>✓ Correct</span>
                          </div>
                          <div className="p-2.5 rounded-lg bg-white/5 border border-white/10 hover:border-emerald-400 cursor-pointer">
                            C) -7
                          </div>
                          <div className="p-2.5 rounded-lg bg-white/5 border border-white/10 hover:border-emerald-400 cursor-pointer">
                            D) -2
                          </div>
                        </div>
                      </div>
                      <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/20 text-xs text-emerald-200">
                        <strong>Step Solution:</strong> Since 2 is a zero, (2)² + 3(2) + k = 0 ⇒ 4 + 6 + k = 0 ⇒ k = -10.
                      </div>
                    </div>
                  )}

                  {activeTabGyanam === 'progress' && (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-xs font-mono text-gray-400 pb-2 border-b border-white/10">
                        <span>STUDENT MASTERY OVERVIEW</span>
                        <span className="text-emerald-400">WEEK 8 PROGRESSION</span>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                          <span className="text-[11px] font-mono text-gray-400">Quadratic Equations</span>
                          <div className="text-xl font-bold text-emerald-300 font-mono mt-1">88% Mastery</div>
                          <div className="w-full h-1.5 bg-white/10 rounded-full mt-2 overflow-hidden">
                            <div className="w-[88%] h-full bg-[#2BB673] rounded-full" />
                          </div>
                        </div>
                        <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                          <span className="text-[11px] font-mono text-gray-400">Chemical Reactions</span>
                          <div className="text-xl font-bold text-emerald-300 font-mono mt-1">94% Mastery</div>
                          <div className="w-full h-1.5 bg-white/10 rounded-full mt-2 overflow-hidden">
                            <div className="w-[94%] h-full bg-[#2BB673] rounded-full" />
                          </div>
                        </div>
                      </div>
                      <div className="p-3 rounded-xl bg-[#12231B] border border-emerald-500/20 text-xs text-gray-300 flex items-center justify-between">
                        <span>Adaptive Next Action: Revision Quiz on Triangles (Class 10)</span>
                        <span className="px-2 py-1 rounded bg-[#2BB673] text-black font-semibold font-mono text-[10px]">
                          START QUIZ
                        </span>
                      </div>
                    </div>
                  )}

                  {activeTabGyanam === 'ledger' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-xs font-mono text-gray-400 pb-2 border-b border-white/10">
                        <span>EVIDENCE-LABELLED MASTERY LEDGER</span>
                        <span className="text-emerald-400">ZERO FABRICATED METRICS</span>
                      </div>
                      <p className="text-xs text-gray-300">
                        Each milestone requires graded evidence from multi-attempt diagnostic questions before advancing conceptual status.
                      </p>
                      <div className="space-y-2 text-xs font-mono">
                        <div className="flex items-center justify-between p-2 rounded bg-white/5">
                          <span className="text-gray-300">Polynomial Zero Calculation</span>
                          <span className="text-emerald-400 font-semibold">[VERIFIED: 3 Tests Passed]</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded bg-white/5">
                          <span className="text-gray-300">Ohm's Law Circuit Problems</span>
                          <span className="text-yellow-400 font-semibold">[TARGET: Needs 2 More Attempts]</span>
                        </div>
                        <div className="flex items-center justify-between p-2 rounded bg-white/5">
                          <span className="text-gray-300">Ray Diagram Focal Length</span>
                          <span className="text-emerald-400 font-semibold">[VERIFIED: High Retention]</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Bottom Status bar */}
                  <div className="pt-4 border-t border-white/10 flex items-center justify-between text-[11px] font-mono text-gray-400">
                    <span>SECURE ENVIRONMENT: NO ADS • NO SURVEILLANCE</span>
                    <span className="text-gray-300">NCERT & STATE BOARD SCOPED</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* THREE CORE ARCHITECTURAL PILLARS */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 md:p-8 rounded-3xl bg-[#FAF8F4] border border-[#181C1A]/10 shadow-xs hover:border-[#1B6B63]/40 transition-all">
            <div className="w-10 h-10 rounded-2xl bg-[#2BB673]/10 text-[#0E2419] flex items-center justify-center mb-4">
              <BookCheck className="w-5 h-5 text-[#2BB673]" />
            </div>
            <h4 className="editorial-title text-xl font-bold text-[#15202B] tracking-tight mb-2">
              Source-Grounded Clarifications
            </h4>
            <p className="text-sm text-[#4E5952] leading-relaxed">
              Explanations are bound strictly to verified board curricula (NCERT and State Boards), eliminating speculative answers and synthetic hallucinations.
            </p>
          </div>

          <div className="p-6 md:p-8 rounded-3xl bg-[#FAF8F4] border border-[#181C1A]/10 shadow-xs hover:border-[#1B6B63]/40 transition-all">
            <div className="w-10 h-10 rounded-2xl bg-[#2BB673]/10 text-[#0E2419] flex items-center justify-center mb-4">
              <Layers className="w-5 h-5 text-[#2BB673]" />
            </div>
            <h4 className="editorial-title text-xl font-bold text-[#15202B] tracking-tight mb-2">
              Step-by-Step Problem Scaffolding
            </h4>
            <p className="text-sm text-[#4E5952] leading-relaxed">
              Rather than handing out direct answers, the intelligent tutor guides learners through Socratic reasoning prompts to build permanent comprehension.
            </p>
          </div>

          <div className="p-6 md:p-8 rounded-3xl bg-[#FAF8F4] border border-[#181C1A]/10 shadow-xs hover:border-[#1B6B63]/40 transition-all">
            <div className="w-10 h-10 rounded-2xl bg-[#2BB673]/10 text-[#0E2419] flex items-center justify-center mb-4">
              <Globe2 className="w-5 h-5 text-[#2BB673]" />
            </div>
            <h4 className="editorial-title text-xl font-bold text-[#15202B] tracking-tight mb-2">
              Multilingual Understanding
            </h4>
            <p className="text-sm text-[#4E5952] leading-relaxed">
              Supports English, Hindi, and regional language switching, ensuring students grasp difficult concepts without linguistic friction.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
