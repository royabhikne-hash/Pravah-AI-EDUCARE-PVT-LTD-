import React from 'react';
import type { ProductItem } from '../data/companyData';
import { X, CheckCircle2, ShieldCheck, Layers } from 'lucide-react';

interface ModalsProps {
  selectedProduct: ProductItem | null;
  onCloseProduct: () => void;
  showPrivacy: boolean;
  onClosePrivacy: () => void;
  showTerms: boolean;
  onCloseTerms: () => void;
}

export const Modals: React.FC<ModalsProps> = ({
  selectedProduct,
  onCloseProduct,
  showPrivacy,
  onClosePrivacy,
  showTerms,
  onCloseTerms,
}) => {
  return (
    <>
      {/* Product Deep Dive Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-2xl my-8 rounded-3xl bg-[#FAF8F4] border border-[#181C1A]/15 p-6 sm:p-10 shadow-2xl max-h-[90vh] overflow-y-auto">
            <button
              onClick={onCloseProduct}
              className="absolute top-6 right-6 p-2 rounded-full hover:bg-black/5 text-[#181C1A]"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-6">
              <span className="px-3 py-1 rounded-full bg-[#E5ECE7] text-[#0E2419] font-mono text-[11px] uppercase tracking-wider font-semibold">
                {selectedProduct.category} • {selectedProduct.status}
              </span>
              <h3 className="editorial-title text-3xl font-extrabold text-[#15202B] mt-3">
                {selectedProduct.name}
              </h3>
              <p className="text-sm font-semibold text-[#1B6B63] font-mono mt-1">
                {selectedProduct.tagline}
              </p>
            </div>

            <p className="text-sm sm:text-base text-[#343C37] leading-relaxed mb-6">
              {selectedProduct.fullDesc}
            </p>

            {/* Core Capabilities */}
            <div className="mb-8">
              <span className="text-xs font-mono uppercase tracking-widest text-[#7E9787] block mb-3">
                Architectural Capabilities
              </span>
              <div className="space-y-3">
                {selectedProduct.capabilities.map((cap, idx) => (
                  <div key={idx} className="p-4 rounded-2xl bg-[#F3EFE6] border border-[#181C1A]/5">
                    <h5 className="text-sm font-bold text-[#15202B] mb-1">{cap.title}</h5>
                    <p className="text-xs text-[#4E5952] leading-relaxed">{cap.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Feature Checklist */}
            <div className="mb-8">
              <span className="text-xs font-mono uppercase tracking-widest text-[#7E9787] block mb-3">
                Verified System Features
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {selectedProduct.features.map((feat, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs text-[#181C1A] p-2.5 rounded-xl bg-white/80 border border-[#181C1A]/5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#2BB673] shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-[#181C1A]/10 flex items-center justify-between text-xs font-mono text-[#7E9787]">
              <span>PRAVAH AI ARCHITECTURE SPECIFICATION</span>
              <button
                onClick={onCloseProduct}
                className="px-5 py-2.5 rounded-full bg-[#0E2419] text-white font-medium hover:bg-[#163525]"
              >
                Close Specification
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Privacy Commitment Modal */}
      {showPrivacy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-xl my-8 rounded-3xl bg-[#FAF8F4] border border-[#181C1A]/15 p-6 sm:p-10 shadow-2xl max-h-[90vh] overflow-y-auto">
            <button
              onClick={onClosePrivacy}
              className="absolute top-6 right-6 p-2 rounded-full hover:bg-black/5 text-[#181C1A]"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 rounded-2xl bg-[#E5ECE7] text-[#0E2419]">
                <ShieldCheck className="w-6 h-6 text-[#2BB673]" />
              </div>
              <div>
                <span className="text-xs font-mono text-[#5F7667] uppercase tracking-wider">
                  Data Governance & Student Trust
                </span>
                <h3 className="text-2xl font-bold text-[#15202B]">
                  Privacy Commitment
                </h3>
              </div>
            </div>

            <div className="space-y-4 text-sm text-[#343C37] leading-relaxed mb-6">
              <p>
                At Pravah AI Educare Private Limited, safeguarding student dignity, intellectual freedom, and personal privacy is our baseline standard.
              </p>
              <div className="p-4 rounded-2xl bg-[#F3EFE6] space-y-2 text-xs font-mono text-[#181C1A]">
                <p>✓ <strong>Zero Commercial Tracking:</strong> We never sell, monetize, or broker student learning data to third-party ad networks.</p>
                <p>✓ <strong>Local-First Enclaves:</strong> Student queries and school tests are processed under localized encrypted sessions.</p>
                <p>✓ <strong>Strict Role Isolation:</strong> Students, teachers, and parents have scoped role-based access. No public leaderboards or shaming.</p>
                <p>✓ <strong>Compliance:</strong> Formulated in strict accordance with the Digital Personal Data Protection (DPDP) Act, 2023.</p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#181C1A]/10 flex items-center justify-between text-xs font-mono text-[#7E9787]">
              <span>Pravah AI Educare Private Limited</span>
              <button
                onClick={onClosePrivacy}
                className="px-5 py-2.5 rounded-full bg-[#0E2419] text-white font-medium hover:bg-[#163525]"
              >
                Acknowledge
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Terms & Ethics Modal */}
      {showTerms && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-xl my-8 rounded-3xl bg-[#FAF8F4] border border-[#181C1A]/15 p-6 sm:p-10 shadow-2xl max-h-[90vh] overflow-y-auto">
            <button
              onClick={onCloseTerms}
              className="absolute top-6 right-6 p-2 rounded-full hover:bg-black/5 text-[#181C1A]"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 rounded-2xl bg-[#E5ECE7] text-[#0E2419]">
                <Layers className="w-6 h-6 text-[#1B6B63]" />
              </div>
              <div>
                <span className="text-xs font-mono text-[#5F7667] uppercase tracking-wider">
                  Ethical Pedagogical Charter
                </span>
                <h3 className="text-2xl font-bold text-[#15202B]">
                  Terms & Operational Ethics
                </h3>
              </div>
            </div>

            <div className="space-y-4 text-sm text-[#343C37] leading-relaxed mb-6">
              <p>
                Pravah AI operates under explicit pedagogical prohibitions:
              </p>
              <ul className="space-y-2 text-xs text-[#4E5952]">
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0 mt-1.5" />
                  <span><strong>No Replacement for Teachers:</strong> Our software assists and scaffolds; it does not displace human educators.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0 mt-1.5" />
                  <span><strong>No Guaranteed Exam Marks:</strong> We reject misleading edtech promises of guaranteed test scores or rank ranks.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0 mt-1.5" />
                  <span><strong>No Fabricated Metrics:</strong> All mastery indicators are evidence-labelled and derived from multi-attempt diagnostic questions.</span>
                </li>
              </ul>
            </div>

            <div className="pt-4 border-t border-[#181C1A]/10 flex items-center justify-between text-xs font-mono text-[#7E9787]">
              <span>Ethical AI Framework</span>
              <button
                onClick={onCloseTerms}
                className="px-5 py-2.5 rounded-full bg-[#0E2419] text-white font-medium hover:bg-[#163525]"
              >
                Accept Terms
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
