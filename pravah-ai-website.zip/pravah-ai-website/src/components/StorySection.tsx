import React from 'react';
import { PRINCIPLES, COMPANY_DETAILS } from '../data/companyData';
import { Compass, Cpu, Target } from 'lucide-react';

export const StorySection: React.FC = () => {
  const principleIcons = [
    <Compass className="w-5 h-5 text-[#2BB673]" />,
    <Cpu className="w-5 h-5 text-[#1B6B63]" />,
    <Target className="w-5 h-5 text-[#0E2419]" />,
  ];

  return (
    <section id="about" className="relative py-28 md:py-36 px-6 md:px-12 lg:px-20 bg-[#FAF8F4] border-t border-[#181C1A]/10">
      <div className="max-w-7xl mx-auto">
        {/* Section Header with Asymmetric Editorial Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start mb-24">
          <div className="lg:col-span-4">
            <div className="sticky top-28 flex flex-col gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono tracking-widest text-[#5F7667] uppercase font-semibold">
                  01 / The Pravah Story
                </span>
              </div>
              <h3 className="text-sm font-mono uppercase tracking-widest text-[#7E9787]">
                Origin & Purpose
              </h3>
              <p className="text-sm text-[#4E5952] leading-relaxed pt-2">
                Pravah (प्रवाह) embodies continual, unobstructed flow — the fluid transmission of knowledge, curiosity, and intelligent reasoning from one mind to another.
              </p>
            </div>
          </div>

          <div className="lg:col-span-8 flex flex-col gap-8">
            <h2 className="editorial-title text-3xl sm:text-5xl md:text-6xl font-bold text-[#15202B] tracking-tight leading-[1.08]">
              Good technology begins with{' '}
              <span className="editorial-italic font-normal text-[#1B6B63]">
                better questions.
              </span>
            </h2>

            <div className="space-y-6 text-base sm:text-lg text-[#343C37] font-normal leading-relaxed">
              <p>
                {COMPANY_DETAILS.storyLead}
              </p>
              <p className="text-[#4E5952]">
                In an educational landscape saturated with passive video lectures and ungrounded chatbots that merely generate superficial answers, we build pedagogical tools that guide students through genuine conceptual mastery. Our engineering prioritizes local hardware resilience, curriculum ground-truth, and respect for teacher authority.
              </p>
            </div>
          </div>
        </div>

        {/* The Three Guiding Principles */}
        <div className="pt-12 border-t border-[#181C1A]/10">
          <div className="flex items-center justify-between mb-12">
            <div>
              <span className="text-xs font-mono uppercase tracking-widest text-[#7E9787]">
                Core Architecture
              </span>
              <h3 className="text-2xl font-bold text-[#15202B] tracking-tight mt-1">
                Foundational Principles
              </h3>
            </div>
            <span className="text-xs font-mono text-[#5F7667] hidden sm:block">
              ENGINEERED FOR RIGOR
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PRINCIPLES.map((principle, index) => (
              <div
                key={principle.number}
                className="group relative p-8 rounded-2xl bg-[#F3EFE6]/60 border border-[#181C1A]/8 hover:border-[#0E2419]/25 transition-all duration-300 hover:shadow-lg hover:-translate-y-1"
              >
                <div className="flex items-center justify-between mb-6">
                  <span className="text-2xl font-mono font-bold text-[#7E9787] group-hover:text-[#0E2419] transition-colors">
                    {principle.number}
                  </span>
                  <div className="p-2 rounded-xl bg-[#FAF8F4] border border-[#181C1A]/5 shadow-2xs">
                    {principleIcons[index]}
                  </div>
                </div>

                <h4 className="text-xl font-bold text-[#15202B] tracking-tight mb-2">
                  {principle.title}
                </h4>

                <p className="text-sm font-semibold text-[#1B6B63] mb-4">
                  {principle.summary}
                </p>

                <p className="text-sm text-[#4E5952] leading-relaxed">
                  {principle.description}
                </p>

                <div className="mt-8 pt-4 border-t border-[#181C1A]/5 flex items-center gap-2 text-xs font-mono text-[#5F7667]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2BB673]" />
                  <span>NON-NEGOTIABLE STANDARD</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
