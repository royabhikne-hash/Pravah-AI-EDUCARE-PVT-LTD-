import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

export const Hero3DCanvas: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [hasWebGL, setHasWebGL] = useState<boolean>(true);
  const [isInteracting, setIsInteracting] = useState<boolean>(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Check WebGL availability
    try {
      const testCanvas = document.createElement('canvas');
      const gl = testCanvas.getContext('webgl') || testCanvas.getContext('experimental-webgl');
      if (!gl) {
        setHasWebGL(false);
        return;
      }
    } catch {
      setHasWebGL(false);
      return;
    }

    let animationFrameId: number;
    let width = container.clientWidth;
    let height = container.clientHeight;

    // Three.js Scene Setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2('#FAF8F4', 0.04);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    // Shift camera slightly so the flow creates an artistic diagonal arc across the screen
    camera.position.set(0.6, 0.8, 11.5);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    container.appendChild(renderer.domElement);

    // Group for all flowing elements
    const ribbonGroup = new THREE.Group();
    // Shift slightly to the right to frame the headline on the left
    ribbonGroup.position.set(1.2, -0.2, 0);
    scene.add(ribbonGroup);

    // Architectural Wireframe Elements (Frames and Rings)
    const architecturalGroup = new THREE.Group();
    architecturalGroup.position.set(1.2, -0.2, 0);
    scene.add(architecturalGroup);

    // 1. Subtle architectural concentric rings
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x7E9787,
      transparent: true,
      opacity: 0.14,
      wireframe: true,
    });

    for (let i = 0; i < 3; i++) {
      const radius = 2.4 + i * 1.3;
      const ringGeo = new THREE.RingGeometry(radius, radius + 0.02, 64);
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = Math.PI / 3 + i * 0.2;
      ringMesh.rotation.y = (i * Math.PI) / 4;
      architecturalGroup.add(ringMesh);
    }

    // 2. Slender floating geometric frames representing structured intelligence
    const frameGeo = new THREE.BoxGeometry(4.0, 2.4, 0.05);
    const frameEdges = new THREE.EdgesGeometry(frameGeo);
    const frameLineMat = new THREE.LineBasicMaterial({
      color: 0x2A684B,
      transparent: true,
      opacity: 0.18,
    });
    const frameLine = new THREE.LineSegments(frameEdges, frameLineMat);
    frameLine.position.set(0.5, 0.2, -1);
    frameLine.rotation.set(0.2, -0.3, 0.1);
    architecturalGroup.add(frameLine);

    // 3. Flowing Ribbon of Particles (Pravah Flow)
    const particleCount = 2600;
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);
    const particleSizes = new Float32Array(particleCount);
    const particleOffsets = new Float32Array(particleCount);

    const colorForest = new THREE.Color('#0E2419');
    const colorTeal = new THREE.Color('#1B6B63');
    const colorEmerald = new THREE.Color('#2BB673');
    const colorSage = new THREE.Color('#7E9787');
    const colorIvory = new THREE.Color('#E5ECE7');

    for (let i = 0; i < particleCount; i++) {
      const t = i / particleCount;
      particleOffsets[i] = t;

      const randColor = Math.random();
      let c = colorForest;
      if (randColor > 0.82) c = colorEmerald;
      else if (randColor > 0.58) c = colorTeal;
      else if (randColor > 0.35) c = colorSage;
      else if (randColor > 0.22) c = colorIvory;

      particleColors[i * 3] = c.r;
      particleColors[i * 3 + 1] = c.g;
      particleColors[i * 3 + 2] = c.b;

      particleSizes[i] = Math.random() * 20 + 8;
    }

    const getFlowPoint = (u: number, time: number) => {
      const a = 3.4;
      const b = 1.6;
      const c = 2.0;
      const angle = u * Math.PI * 4 + time * 0.22;

      const x = Math.sin(angle) * (a + Math.cos(angle * 1.5) * 0.7);
      const y = Math.cos(angle * 2) * b + Math.sin(time * 0.35 + u * 6) * 0.35;
      const z = Math.sin(angle * 3) * (c * 0.55) + Math.cos(angle) * 1.1;

      const spread = Math.sin(u * 20 + time) * 0.3;
      return new THREE.Vector3(x + spread, y + spread * 0.5, z);
    };

    const particleGeometry = new THREE.BufferGeometry();
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));
    particleGeometry.setAttribute('size', new THREE.BufferAttribute(particleSizes, 1));

    const particleMaterial = new THREE.ShaderMaterial({
      vertexShader: `
        attribute float size;
        varying vec3 vColor;
        varying float vAlpha;
        void main() {
          vColor = color;
          vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = size * (16.0 / -mvPosition.z);
          vAlpha = smoothstep(-15.0, -3.0, mvPosition.z);
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        varying vec3 vColor;
        varying float vAlpha;
        void main() {
          vec2 coord = gl_PointCoord - vec2(0.5);
          float dist = length(coord);
          if (dist > 0.5) discard;
          float strength = 1.0 - (dist * 2.0);
          strength = pow(strength, 1.5);
          gl_FragColor = vec4(vColor, strength * 0.75 * vAlpha);
        }
      `,
      transparent: true,
      vertexColors: true,
      depthWrite: false,
      blending: THREE.NormalBlending,
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    ribbonGroup.add(particles);

    // Mouse & Pointer Interaction
    let targetMouseX = 0;
    let targetMouseY = 0;
    let currentMouseX = 0;
    let currentMouseY = 0;

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      let clientX = 0;
      let clientY = 0;

      if ('touches' in e && e.touches.length > 0) {
        clientX = e.touches[0].clientX;
        clientY = e.touches[0].clientY;
      } else if ('clientX' in e) {
        clientX = (e as MouseEvent).clientX;
        clientY = (e as MouseEvent).clientY;
      }

      const rect = container.getBoundingClientRect();
      const x = (clientX - rect.left) / rect.width;
      const y = (clientY - rect.top) / rect.height;

      targetMouseX = (x - 0.5) * 2;
      targetMouseY = (y - 0.5) * 2;
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: true });
    window.addEventListener('touchmove', handlePointerMove, { passive: true });

    let scrollY = 0;
    const handleScroll = () => {
      scrollY = window.scrollY;
    };
    window.addEventListener('scroll', handleScroll, { passive: true });

    const handleResize = () => {
      if (!container) return;
      width = container.clientWidth;
      height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    window.addEventListener('resize', handleResize);

    const startTime = performance.now();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = (performance.now() - startTime) * 0.001;

      currentMouseX += (targetMouseX - currentMouseX) * 0.05;
      currentMouseY += (targetMouseY - currentMouseY) * 0.05;

      const posAttr = particleGeometry.attributes.position as THREE.BufferAttribute;
      const posArray = posAttr.array as Float32Array;

      const flowSpeed = isInteracting ? 0.3 : 0.16;

      for (let i = 0; i < particleCount; i++) {
        const offset = particleOffsets[i];
        const pt = getFlowPoint(offset, elapsedTime * flowSpeed);

        posArray[i * 3] = pt.x;
        posArray[i * 3 + 1] = pt.y;
        posArray[i * 3 + 2] = pt.z;
      }
      posAttr.needsUpdate = true;

      ribbonGroup.rotation.y = elapsedTime * 0.05 + currentMouseX * 0.35;
      ribbonGroup.rotation.x = Math.sin(elapsedTime * 0.03) * 0.12 - currentMouseY * 0.25;
      ribbonGroup.position.y = -0.2 - scrollY * 0.001;

      architecturalGroup.rotation.y = -elapsedTime * 0.025 + currentMouseX * 0.15;
      architecturalGroup.rotation.x = Math.cos(elapsedTime * 0.025) * 0.08 - currentMouseY * 0.12;
      architecturalGroup.position.y = -0.2 - scrollY * 0.0007;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleResize);

      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
      particleGeometry.dispose();
      particleMaterial.dispose();
    };
  }, [isInteracting]);

  return (
    <div
      ref={containerRef}
      onMouseDown={() => setIsInteracting(true)}
      onMouseUp={() => setIsInteracting(false)}
      onTouchStart={() => setIsInteracting(true)}
      onTouchEnd={() => setIsInteracting(false)}
      className="absolute inset-0 w-full h-full pointer-events-auto cursor-grab active:cursor-grabbing select-none overflow-hidden"
      aria-label="Interactive 3D dynamic particle flow representing Pravah AI"
    >
      {!hasWebGL && (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-ivory-100 to-ivory-300">
          <div className="w-80 h-80 rounded-full border border-sage-300/40 animate-pulse-subtle flex items-center justify-center">
            <div className="w-56 h-56 rounded-full border border-forest-600/30 flex items-center justify-center">
              <div className="w-32 h-32 rounded-full bg-forest-900/10 backdrop-blur-sm" />
            </div>
          </div>
        </div>
      )}

      {/* Floating Interactive Badge */}
      <div className="absolute bottom-6 right-6 z-10 hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-ivory/80 backdrop-blur-md border border-charcoal/10 text-[11px] font-mono text-charcoal-600 pointer-events-none">
        <span className="w-2 h-2 rounded-full bg-brand-green animate-pulse" />
        <span>FLOW EMBEDDED — DRAG TO MODULATE STREAM</span>
      </div>
    </div>
  );
};
