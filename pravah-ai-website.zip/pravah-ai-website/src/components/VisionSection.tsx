import React from 'react';
import { ArrowUpRight, Orbit } from 'lucide-react';

interface VisionSectionProps {
  onCollaborate: () => void;
}

export const VisionSection: React.FC<VisionSectionProps> = ({ onCollaborate }) => {
  return (
    <section className="relative py-32 md:py-40 px-6 md:px-12 lg:px-20 bg-[#0E2419] text-[#FAF8F4] overflow-hidden">
      {/* Architectural Grid Background */}
      <div className="absolute inset-0 bg-architectural-grid-dark opacity-35 pointer-events-none" />

      {/* Atmospheric Glowing Gradients */}
      <div className="absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full bg-[#2BB673]/10 blur-[140px] pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-[600px] h-[600px] rounded-full bg-[#1B6B63]/15 blur-[140px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Tag */}
        <div className="flex items-center gap-2 mb-6">
          <span className="text-xs font-mono tracking-widest text-[#2BB673] uppercase font-semibold">
            06 / Long-Term Horizon
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start mb-20">
          <div className="lg:col-span-8">
            <h2 className="editorial-title text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight leading-[1.04]">
              Built for what{' '}
              <span className="editorial-italic font-normal text-[#34D399]">
                comes next.
              </span>
            </h2>

            <div className="mt-8 space-y-6 text-base sm:text-lg text-gray-300 font-light leading-relaxed max-w-2xl">
              <p>
                We envision a future where high-fidelity, personalized education is not a luxury reserved for elite private schooling, but an ambient, universally accessible utility embedded within every classroom.
              </p>
              <p className="text-gray-400">
                By combining domain-tuned compact neural architectures with verifiable pedagogical guardrails, we are engineering systems that adapt to the student’s pace, demystify complex curriculum standards, and give classroom teachers superpowers rather than displacing them.
              </p>
            </div>
          </div>

          <div className="lg:col-span-4 bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-md flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-[#2BB673] mb-4">
                <Orbit className="w-4 h-4" />
                <span>EXPLORATORY HORIZONS</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-3">
                Research Directions
              </h3>
              <ul className="space-y-3 text-xs text-gray-300 font-mono">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2BB673]" />
                  <span>Sub-1B Parameter Educational Engines</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2BB673]" />
                  <span>Multimodal Diagram & Handwriting Analysis</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2BB673]" />
                  <span>Decentralized Classroom Knowledge Nodes</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#2BB673]" />
                  <span>Zero-Data Retention Privacy Enclaves</span>
                </li>
              </ul>
            </div>

            <div className="mt-8 pt-4 border-t border-white/10 text-[11px] font-mono text-gray-400">
              Target Roadmap: 2026–2028
            </div>
          </div>
        </div>

        {/* Refined Invitation to Collaborate */}
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-[#143525] to-[#0A1C13] border border-white/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-8">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-[#2BB673] block mb-1">
              Partnerships & Co-Creation
            </span>
            <h3 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Shape the next decade of intelligent educare.
            </h3>
            <p className="text-sm text-gray-300 mt-1 max-w-xl">
              We collaborate with forward-looking school boards, universities, cognitive researchers, and technical partners.
            </p>
          </div>

          <button
            onClick={onCollaborate}
            className="inline-flex items-center gap-2.5 px-8 py-4 rounded-full bg-[#2BB673] hover:bg-[#34D399] text-[#0E2419] font-bold text-sm tracking-tight transition-all duration-200 hover:scale-105 active:scale-95 shadow-[0_0_30px_rgba(43,182,115,0.4)] whitespace-nowrap"
          >
            <span>Let's Collaborate</span>
            <ArrowUpRight className="w-4 h-4 text-[#0E2419]" />
          </button>
        </div>
      </div>
    </section>
  );
};
