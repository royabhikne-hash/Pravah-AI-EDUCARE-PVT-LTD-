import React, { useState } from 'react';
import { TEAM_MEMBERS } from '../data/companyData';
import type { TeamMember } from '../data/companyData';
import { ArrowUpRight, Shield, Sparkles } from 'lucide-react';

export const TeamSection: React.FC = () => {
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  // Gradient styling for the four founders
  const cardGradients: Record<string, string> = {
    'AB': 'from-[#D9E2DC] via-[#C8D6CD] to-[#B3C4B9]',
    'DH': 'from-[#CCD8D0] via-[#BBCDC1] to-[#A8BFA9]',
    'SA': 'from-[#DDE4DF] via-[#CCD7D0] to-[#BAC8BD]',
    'PR': 'from-[#E2E8E4] via-[#D0DCD3] to-[#BCCBC0]',
  };

  return (
    <section id="team" className="relative py-28 md:py-36 px-6 md:px-12 lg:px-20 bg-[#FAF8F4] border-t border-[#181C1A]/10">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-mono tracking-widest text-[#5F7667] uppercase font-semibold">
                05 / Leadership & Team
              </span>
            </div>
            <h2 className="editorial-title text-3xl sm:text-5xl md:text-6xl font-bold text-[#15202B] tracking-tight">
              Built by{' '}
              <span className="editorial-italic font-normal text-[#1B6B63]">
                independent thinkers.
              </span>
            </h2>
            <p className="text-base text-[#4E5952] max-w-xl mt-3">
              The founding engineers and operators directing Pravah AI Educare Private Limited.
            </p>
          </div>

          <div className="text-xs font-mono text-[#5F7667] flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#2BB673]" />
            <span>EXECUTIVE FOUNDING BOARD</span>
          </div>
        </div>

        {/* Four Portrait Panels */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {TEAM_MEMBERS.map((member) => {
            const grad = cardGradients[member.monogram] || 'from-[#CCD8D0] to-[#A8BFA9]';
            return (
              <div
                key={member.id}
                onClick={() => setSelectedMember(member)}
                className="group relative cursor-pointer select-none"
              >
                {/* Portrait Container */}
                {member.image ? (
                  <div
                    className="relative w-full aspect-[4/5] rounded-3xl p-6 flex flex-col justify-between overflow-hidden border border-[#181C1A]/10 shadow-sm transition-all duration-300 group-hover:-translate-y-2 group-hover:shadow-xl bg-[#FAF8F4]"
                  >
                    {/* Actual Founder Photograph — Bright, Natural, Vivid */}
                    <img
                      src={member.image}
                      alt={member.name}
                      className="absolute inset-0 w-full h-full object-cover object-top brightness-[1.04] contrast-[1.02] transition-transform duration-500 group-hover:scale-105"
                    />

                    {/* Gradient scrim ONLY at bottom for footer text legibility — faces remain completely bright */}
                    <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-black/85 via-black/35 to-transparent pointer-events-none" />

                    {/* Top Bar: Co-Founder badge */}
                    <div className="relative z-10 flex items-center justify-between">
                      <span className="text-[10px] font-mono tracking-[0.2em] uppercase font-bold text-[#0E2419] bg-white/90 px-2.5 py-1 rounded-full backdrop-blur-md shadow-xs border border-black/5">
                        CO-FOUNDER
                      </span>
                      <span className="w-7 h-7 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-xs">
                        <ArrowUpRight className="w-3.5 h-3.5 text-[#0E2419]" />
                      </span>
                    </div>

                    {/* Spacer */}
                    <div className="relative z-10 my-auto" />

                    {/* Hover Info Reveal Overlay */}
                    <div className="relative z-10 pt-2 border-t border-white/20 flex items-center justify-between text-[11px] font-mono text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.8)]">
                      <span>{member.department.split('&')[0].trim()}</span>
                      <span className="font-semibold text-[#2BB673]">VIEW ROLE →</span>
                    </div>
                  </div>
                ) : (
                  <div
                    className={`relative w-full aspect-[4/5] rounded-3xl bg-gradient-to-b ${grad} p-6 flex flex-col justify-between overflow-hidden border border-[#181C1A]/10 shadow-sm transition-all duration-300 group-hover:-translate-y-2 group-hover:shadow-xl`}
                  >
                    {/* Subtle Noise / Grain Texture */}
                    <div className="absolute inset-0 opacity-25 mix-blend-overlay bg-[radial-gradient(#181C1A_1px,transparent_1px)] [background-size:16px_16px]" />

                    {/* Top Bar: Co-Founder badge */}
                    <div className="relative z-10 flex items-center justify-between">
                      <span className="text-[10px] font-mono tracking-[0.2em] uppercase font-bold text-[#15202B]/75 bg-white/40 px-2.5 py-1 rounded-full backdrop-blur-xs">
                        CO-FOUNDER
                      </span>
                      <span className="w-7 h-7 rounded-full bg-white/50 backdrop-blur-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <ArrowUpRight className="w-3.5 h-3.5 text-[#0E2419]" />
                      </span>
                    </div>

                    {/* Gigantic Sculptural Monogram Typography */}
                    <div className="relative z-10 my-auto text-center">
                      <span className="editorial-italic font-serif text-7xl sm:text-8xl md:text-9xl font-light text-white/90 drop-shadow-[0_2px_12px_rgba(0,0,0,0.06)] group-hover:scale-105 transition-transform duration-300 block select-none">
                        {member.monogram}
                      </span>
                    </div>

                    {/* Hover Info Reveal Overlay */}
                    <div className="relative z-10 pt-2 border-t border-black/10 flex items-center justify-between text-[11px] font-mono text-[#15202B]/80">
                      <span>{member.department.split('&')[0].trim()}</span>
                      <span className="font-semibold text-[#0E2419]">VIEW ROLE →</span>
                    </div>
                  </div>
                )}

                {/* Bottom Meta */}
                <div className="mt-4 px-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-lg font-bold text-[#15202B] tracking-tight group-hover:text-[#1B6B63] transition-colors">
                      {member.name}
                    </h4>
                  </div>
                  <p className="text-xs text-[#5F7667] font-medium mt-0.5">
                    {member.role}
                  </p>
                  <p className="text-xs text-[#7E9787] font-mono mt-1 line-clamp-1">
                    {member.responsibilities[0]}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Authentic Founder Data Notice */}
        <div className="mt-12 p-6 rounded-2xl bg-[#F3EFE6]/60 border border-[#181C1A]/8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#5F7667]">
          <p>
            Executive founding board of Pravah AI Educare Private Limited. Official records verified at the Registrar of Companies, Karnataka.
          </p>
          <span className="font-mono text-[#0E2419] whitespace-nowrap">
            CIN: U85499KA2026PTC222183
          </span>
        </div>

        {/* Member Profile Modal */}
        {selectedMember && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="relative w-full max-w-xl rounded-3xl bg-[#FAF8F4] border border-[#181C1A]/15 p-8 md:p-10 shadow-2xl">
              <button
                onClick={() => setSelectedMember(null)}
                className="absolute top-6 right-6 p-2 rounded-full hover:bg-black/5 text-[#181C1A] cursor-pointer"
                aria-label="Close modal"
              >
                ✕
              </button>

              <div className="flex items-center gap-4 mb-6">
                {selectedMember.image ? (
                  <img
                    src={selectedMember.image}
                    alt={selectedMember.name}
                    className="w-20 h-20 rounded-2xl object-cover object-top border-2 border-white shadow-md brightness-105"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#CCD8D0] to-[#7E9787] flex items-center justify-center">
                    <span className="editorial-italic font-serif text-3xl text-white font-light">
                      {selectedMember.monogram}
                    </span>
                  </div>
                )}
                <div>
                  <span className="text-xs font-mono text-[#2BB673] uppercase tracking-wider font-semibold">
                    CO-FOUNDER • {selectedMember.department}
                  </span>
                  <h3 className="text-2xl font-bold text-[#15202B]">
                    {selectedMember.name}
                  </h3>
                  <p className="text-sm text-[#5F7667]">{selectedMember.role}</p>
                </div>
              </div>

              <p className="text-sm text-[#343C37] leading-relaxed mb-6">
                {selectedMember.bio}
              </p>

              <div className="mb-6">
                <span className="text-xs font-mono uppercase tracking-widest text-[#7E9787] block mb-3">
                  Key Strategic Responsibilities
                </span>
                <div className="space-y-2">
                  {selectedMember.responsibilities.map((resp, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-[#F3EFE6] border border-[#181C1A]/5 text-xs text-[#181C1A] flex items-center gap-2"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#2BB673] shrink-0" />
                      <span>{resp}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-[#181C1A]/10 flex items-center justify-between text-xs font-mono text-[#7E9787]">
                <span>Pravah AI Educare Private Limited</span>
                <button
                  onClick={() => setSelectedMember(null)}
                  className="px-4 py-2 rounded-full bg-[#0E2419] text-white text-xs font-medium"
                >
                  Close Profile
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
