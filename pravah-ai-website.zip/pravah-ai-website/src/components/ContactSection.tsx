import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { CheckCircle2, AlertCircle, ArrowUpRight, Mail, MapPin, Building2 } from 'lucide-react';
import { COMPANY_DETAILS } from '../data/companyData';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    organization: '',
    inquiryType: 'Educational Institution',
    message: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  const inquiryTypes = [
    'Educational Institution',
    'Strategic Partnership',
    'Technical Collaboration',
    'Investment & Advisory',
    'General Inquiry',
  ];

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) {
      errs.name = 'Please provide your full name.';
    }
    if (!formData.email.trim()) {
      errs.email = 'Please provide a valid email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errs.email = 'Please enter a valid email format.';
    }
    if (!formData.message.trim()) {
      errs.message = 'Please include a brief message or question.';
    } else if (formData.message.trim().length < 10) {
      errs.message = 'Please provide at least 10 characters so we can understand your request.';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    // Simulate reliable dispatch
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);

      // Trigger refined confetti celebration
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 },
          colors: ['#2BB673', '#1B6B63', '#7E9787', '#FAF8F4'],
        });
      } catch {
        // Safe fallback if canvas is restricted
      }
    }, 900);
  };

  const handleReset = () => {
    setFormData({
      name: '',
      email: '',
      organization: '',
      inquiryType: 'Educational Institution',
      message: '',
    });
    setErrors({});
    setIsSubmitted(false);
  };

  return (
    <section id="contact" className="relative py-28 md:py-36 px-6 md:px-12 lg:px-20 bg-[#FAF8F4] border-t border-[#181C1A]/10">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Editorial Heading & Context (from Reference Video) */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            <div>
              {/* Eyebrow */}
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-px bg-[#2BB673]" />
                <span className="text-xs font-mono uppercase tracking-[0.2em] text-[#5F7667] font-semibold">
                  CONTACT PRAVAH
                </span>
              </div>

              {/* Editorial Large Heading */}
              <h2 className="editorial-title text-4xl sm:text-6xl md:text-7xl font-extrabold text-[#15202B] tracking-tight leading-[1.05] mb-6">
                Let's start a{' '}
                <span className="editorial-italic font-normal text-[#1B6B63]">
                  conversation.
                </span>
              </h2>

              <p className="text-base sm:text-lg text-[#4E5952] leading-relaxed mb-10 max-w-md">
                For product questions, institutional interest, collaborations, or simply to say hello.
              </p>

              {/* Verified Office Information */}
              <div className="space-y-4 pt-6 border-t border-[#181C1A]/10 text-xs font-mono text-[#5F7667]">
                <div className="flex items-start gap-3">
                  <Building2 className="w-4 h-4 text-[#2BB673] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#15202B] block">Corporate Entity</span>
                    <span>{COMPANY_DETAILS.legalName}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#1B6B63] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#15202B] block">Registered Office</span>
                    <span className="leading-relaxed">{COMPANY_DETAILS.registeredAddress}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-4 h-4 text-[#7E9787] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#15202B] block">Direct Contact</span>
                    <a href={`mailto:${COMPANY_DETAILS.officialEmail}`} className="text-[#0E2419] underline hover:text-[#2BB673]">
                      {COMPANY_DETAILS.officialEmail}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 hidden lg:block text-[11px] font-mono text-[#7E9787]">
              RESPONSE WINDOW: TYPICALLY WITHIN 24–48 BUSINESS HOURS
            </div>
          </div>

          {/* Right Column: Premium Accessible Form */}
          <div className="lg:col-span-7">
            <div className="rounded-3xl bg-[#F4F0E6]/70 border border-[#181C1A]/10 p-8 sm:p-12 shadow-sm">
              {isSubmitted ? (
                /* Refined Confirmation State (Elevated from Reference Video) */
                <div className="py-10 flex flex-col items-start gap-6 animate-fade-in">
                  <div className="w-14 h-14 rounded-full bg-[#2BB673]/20 flex items-center justify-center border border-[#2BB673]/30">
                    <CheckCircle2 className="w-7 h-7 text-[#2BB673]" />
                  </div>

                  <div>
                    <h3 className="editorial-title text-3xl font-bold text-[#15202B] mb-2">
                      Thanks for reaching out.
                    </h3>
                    <p className="text-sm text-[#4E5952] leading-relaxed max-w-lg">
                      Your inquiry has been recorded into our correspondence registry. Our founding team will review your message and connect back with you at{' '}
                      <span className="font-semibold text-[#0E2419]">{formData.email}</span>.
                    </p>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#FAF8F4] border border-[#181C1A]/8 w-full text-xs font-mono text-[#5F7667]">
                    <div className="flex justify-between mb-1">
                      <span>INQUIRY ROUTE:</span>
                      <span className="font-bold text-[#0E2419]">{formData.inquiryType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>SENDER:</span>
                      <span>{formData.name} {formData.organization ? `(${formData.organization})` : ''}</span>
                    </div>
                  </div>

                  <button
                    onClick={handleReset}
                    className="inline-flex items-center gap-2 text-xs font-semibold text-[#0E2419] underline hover:text-[#2BB673] transition-colors mt-2"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                /* Interactive Form */
                <form onSubmit={handleSubmit} className="space-y-6" noValidate>
                  {/* Full Name */}
                  <div>
                    <label
                      htmlFor="fullName"
                      className="block text-xs font-mono uppercase tracking-wider text-[#15202B] font-semibold mb-2"
                    >
                      Name <span className="text-[#2BB673]">*</span>
                    </label>
                    <input
                      id="fullName"
                      type="text"
                      placeholder="Your name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full px-4 py-3.5 rounded-xl bg-[#FAF8F4] border text-sm text-[#181C1A] placeholder:text-[#7E9787] focus:outline-none focus:ring-2 transition-all ${
                        errors.name
                          ? 'border-red-400 focus:ring-red-200'
                          : 'border-[#181C1A]/10 focus:border-[#0E2419] focus:ring-[#0E2419]/10'
                      }`}
                    />
                    {errors.name && (
                      <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1 font-mono">
                        <AlertCircle className="w-3.5 h-3.5" />
                        {errors.name}
                      </p>
                    )}
                  </div>

                  {/* Email Address */}
                  <div>
                    <label
                      htmlFor="email"
                      className="block text-xs font-mono uppercase tracking-wider text-[#15202B] font-semibold mb-2"
                    >
                      Email <span className="text-[#2BB673]">*</span>
                    </label>
                    <input
                      id="email"
                      type="email"
                      placeholder="you@company.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className={`w-full px-4 py-3.5 rounded-xl bg-[#FAF8F4] border text-sm text-[#181C1A] placeholder:text-[#7E9787] focus:outline-none focus:ring-2 transition-all ${
                        errors.email
                          ? 'border-red-400 focus:ring-red-200'
                          : 'border-[#181C1A]/10 focus:border-[#0E2419] focus:ring-[#0E2419]/10'
                      }`}
                    />
                    {errors.email && (
                      <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1 font-mono">
                        <AlertCircle className="w-3.5 h-3.5" />
                        {errors.email}
                      </p>
                    )}
                  </div>

                  {/* Organization (Optional) */}
                  <div>
                    <label
                      htmlFor="organization"
                      className="block text-xs font-mono uppercase tracking-wider text-[#15202B] font-semibold mb-2"
                    >
                      Organization <span className="text-[#7E9787] text-[10px] font-normal">(optional)</span>
                    </label>
                    <input
                      id="organization"
                      type="text"
                      placeholder="School, Institution, or Organization"
                      value={formData.organization}
                      onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                      className="w-full px-4 py-3.5 rounded-xl bg-[#FAF8F4] border border-[#181C1A]/10 text-sm text-[#181C1A] placeholder:text-[#7E9787] focus:outline-none focus:border-[#0E2419] focus:ring-2 focus:ring-[#0E2419]/10 transition-all"
                    />
                  </div>

                  {/* Inquiry Type Radio Pills */}
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#15202B] font-semibold mb-2">
                      Inquiry Category
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {inquiryTypes.map((type) => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => setFormData({ ...formData, inquiryType: type })}
                          className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                            formData.inquiryType === type
                              ? 'bg-[#0E2419] text-[#FAF8F4] shadow-xs'
                              : 'bg-[#FAF8F4] text-[#343C37] border border-[#181C1A]/10 hover:border-[#0E2419]/30'
                          }`}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label
                      htmlFor="message"
                      className="block text-xs font-mono uppercase tracking-wider text-[#15202B] font-semibold mb-2"
                    >
                      Message <span className="text-[#2BB673]">*</span>
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      placeholder="How can we help?"
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className={`w-full px-4 py-3.5 rounded-xl bg-[#FAF8F4] border text-sm text-[#181C1A] placeholder:text-[#7E9787] focus:outline-none focus:ring-2 transition-all resize-none ${
                        errors.message
                          ? 'border-red-400 focus:ring-red-200'
                          : 'border-[#181C1A]/10 focus:border-[#0E2419] focus:ring-[#0E2419]/10'
                      }`}
                    />
                    {errors.message && (
                      <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1 font-mono">
                        <AlertCircle className="w-3.5 h-3.5" />
                        {errors.message}
                      </p>
                    )}
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-[#0E2419] hover:bg-[#163525] disabled:bg-gray-400 text-[#FAF8F4] text-sm font-semibold tracking-wide transition-all duration-200 hover:shadow-md cursor-pointer"
                  >
                    {isSubmitting ? (
                      <span className="flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Connecting...
                      </span>
                    ) : (
                      <>
                        <span>Send Inquiry</span>
                        <ArrowUpRight className="w-4 h-4 text-[#2BB673]" />
                      </>
                    )}
                  </button>

                  <div className="flex items-center justify-between text-[11px] font-mono text-[#7E9787] pt-2">
                    <span>PRIVACY: ZERO THIRD-PARTY TRACKING</span>
                    <span>SECURE DIRECT INTAKE</span>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
