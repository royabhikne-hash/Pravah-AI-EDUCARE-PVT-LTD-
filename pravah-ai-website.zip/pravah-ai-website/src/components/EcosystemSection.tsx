// Ecosystem section removed per user specification
export const EcosystemSection = () => null;
