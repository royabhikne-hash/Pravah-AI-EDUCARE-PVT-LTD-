import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { StorySection } from './components/StorySection';
import { ProductsSection } from './components/ProductsSection';
import { ApproachSection } from './components/ApproachSection';
import { TeamSection } from './components/TeamSection';
import { VisionSection } from './components/VisionSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { Modals } from './components/Modals';
import type { ProductItem } from './data/companyData';

export function App() {
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);
  const [showPrivacy, setShowPrivacy] = useState<boolean>(false);
  const [showTerms, setShowTerms] = useState<boolean>(false);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#FAF8F4] text-[#181C1A] selection:bg-[#2BB673]/20 selection:text-[#0E2419]">
      {/* Navigation */}
      <Navbar onOpenContact={() => scrollTo('contact')} />

      {/* Main Content Flow */}
      <main id="main-content">
        {/* 01. Hero Signature Experience */}
        <Hero
          onExploreWork={() => scrollTo('products')}
          onMeetPravah={() => scrollTo('about')}
        />

        {/* 02. The Pravah Story & Philosophy */}
        <StorySection />

        {/* 03. Products & Projects Portfolio */}
        <ProductsSection onSelectProduct={(prod) => setSelectedProduct(prod)} />

        {/* 04. Our Methodology & Approach */}
        <ApproachSection />

        {/* 06. Executive Founding Team */}
        <TeamSection />

        {/* 07. Vision & Future Horizons */}
        <VisionSection onCollaborate={() => scrollTo('contact')} />

        {/* 08. Contact & Conversation */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer
        onOpenPrivacy={() => setShowPrivacy(true)}
        onOpenTerms={() => setShowTerms(true)}
      />

      {/* Interactive Modals */}
      <Modals
        selectedProduct={selectedProduct}
        onCloseProduct={() => setSelectedProduct(null)}
        showPrivacy={showPrivacy}
        onClosePrivacy={() => setShowPrivacy(false)}
        showTerms={showTerms}
        onCloseTerms={() => setShowTerms(false)}
      />
    </div>
  );
}

export default App;
