/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ivory: {
          DEFAULT: '#FAF8F4',
          50: '#FFFFFF',
          100: '#FAF8F4',
          200: '#F3EFE6',
          300: '#EAE4D6',
          400: '#DDD5C4',
        },
        forest: {
          DEFAULT: '#0E2419',
          950: '#07130D',
          900: '#0B1C13',
          850: '#0E2419',
          800: '#143525',
          700: '#1D4934',
          600: '#2A684B',
        },
        sage: {
          DEFAULT: '#7E9787',
          50: '#F4F7F5',
          100: '#E5ECE7',
          200: '#CCD8D0',
          300: '#AEC1B4',
          400: '#8FA996',
          500: '#7E9787',
          600: '#5F7667',
        },
        charcoal: {
          DEFAULT: '#181C1A',
          800: '#222824',
          700: '#343C37',
          600: '#4E5952',
          400: '#7D8A82',
        },
        brand: {
          green: '#2BB673',
          teal: '#1B6B63',
          lime: '#4ADE80',
          dark: '#15202B',
        }
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        serif: ['Newsreader', 'Playfair Display', 'Georgia', 'serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      animation: {
        'pulse-subtle': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float-slow': 'float 8s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        }
      }
    },
  },
  plugins: [],
}
